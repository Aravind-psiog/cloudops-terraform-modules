import json


def lambda_handler(event, context):
    # TODO implement
    return event
